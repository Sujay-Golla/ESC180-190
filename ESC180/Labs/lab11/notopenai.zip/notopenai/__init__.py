from .client import NotOpenAI
