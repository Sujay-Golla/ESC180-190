## What is NotOpenAI?
This is a module which has the exact same API as OpenAI. It uses a server in between the user and OpenAI so that students can use the API without paying